happyLeaf.factory('storageManager', ['$rootScope', 'dataManager', '$localStorage', function($rootScope, dataManager, $localStorage){
  var createHistoryPoint = function(){
    dataManager.endTime = (new Date()).getTime();
    var currentDataManager = Object.assign({}, dataManager);
    async.forEach(Object.keys(currentDataManager), function(key){
      if(typeof currentDataManager[key] == 'function'){
        delete currentDataManager[key];
      }
    });
    var now = (new Date()).getTime();
    $localStorage.history[now] = currentDataManager;
    dataManager.historyCreated();
    $rootScope.$broadcast('historyUpdated');
    console.log("Creating history point with this data");
    console.log($localStorage.history);
  };

  var self = {
    db: null,


    startupDB: function(){
      $rootScope.$on('dataUpdate', function(event, data){
        console.log("Going to save this data " + data.keys().join());
        //check here if an interval should be saved.
      });

      self.db = window.sqlitePlugin.openDatabase({name: 'happyLeaf.db', location: 'default'});

      self.db.transaction(function(tx) {
       tx.executeSql('CREATE TABLE IF NOT EXISTS Trips (time_start, time_end, id, start_KW, end_KW, start_odo, end_obo)');
       console.log("Try to loop over keys avaliable in dataManager");
       console.log(dataManager.keys().join());
       tx.executeSql('CREATE TABLE IF NOT EXISTS TripIntervals (time_start, time_end, id)');
       //tx.executeSql('INSERT INTO DemoTable VALUES (?,?)', ['Alice', 101]);
       //tx.executeSql('INSERT INTO DemoTable VALUES (?,?)', ['Betty', 202]);
     }, function(error) {
       console.log('Transaction ERROR: ' + error.message);
     }, function() {
       console.log('Populated database OK');
     });


   }
  };

  //if(!$localStorage.history) {
    $localStorage.history = {

    };
  //}

  setInterval(createHistoryPoint, 30000);
  createHistoryPoint();

  return self;
}]);
